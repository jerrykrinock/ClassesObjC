#import <Cocoa/Cocoa.h>

/*!
 @brief    Produces a fat Help Arrow with a blue gradient and
 white border, with some animation, similar to the one you
 get in a Cocoa app when you click Help, search for a menu item
 and select the result.

 @details  The fat blue arrow is an attached window.
 
 It is instantiated as a singleton.  (Certainly one would not want more
 than one of these buggers displayed at once!)
 
 Apple's fat blue menu-item pointer makes a little circule continuously.
 I think that's kind of confusing, and since Marcus Zarra's animation
 code (acknowledged below) shakes the arrow back and forth, I gave it
 parameters to point at the target point three times and then stop.
 I like this much better than the little circles.
 
 You'll need to link /System/Library/Frameworks/QuartzCore.framework
 into any project including this class.
 
 Requires SDK Mac OS 10.5 or later.

 ACKNOWLEDGEMENTS
 
 The idea to use an attached window, and most of the heavy lifting code,
 was copied and modified from the MAAttachedWindow:
 http://mattgemmell.com/2007/10/03/maattachedwindow-nswindow-subclass
 written by Matt Gemmell, http://mattgemmell.com 
 
 Code for using Core Animation to animate the window was copied and
 modified from the Core Animation Tutorial: Window Shake Effect:
 http://www.cimgf.com/2008/02/27/core-animation-tutorial-window-shake-effect/
 written by Marcus Zarra, http://www.zarrastudios.com/ZDS/Home/Home.html
  
 And thanks to Jonathan Muggins for directing me to both of the above.
 http://www.mugginsoft.com
*/
@interface SSYHintArrow : NSWindow {
    NSColor* m_borderColor ;
    float m_borderWidth ;
    float m_viewMargin ;
    float m_arrowHeight ;
    float m_cornerRadius ;
    NSSize m_size ;
	
    @private
	NSGradient* m_gradient ;
    __weak NSView* m_view ;
    __weak NSWindow* m_window ;
    NSPoint m_point ;
    float m_distance ;
    NSRect m_viewFrame ;
    BOOL m_isResizingLockout ;
}

/*
 @brief    Creates and attaches a Help Arrow

 @param    point  The point, in the coordinate system of the 
 given window, at which the arrowhead (the left end) of the
 arrow will be placed.
 @param    window  The window to which the Help Arrow should
 be attached.
*/
+ (void)showHelpArrowAtPoint:(NSPoint)point
					inWindow:(NSWindow*)window ;

/*!
 @brief    Removes and destroys a Help Arrow created by
 showHelpArrowAtPoint:inWindow:
 
 @details  Usually, you'll want to remove the arrow whenever
 the user clicks any mouse button or any key.  There is no Cocoa
 method to get exactly that.  I do it by subclassing the host
 window, if not already subclassed, and overriding -sendEvent:
 to send a notification:
 
 NSString* const SSYDocChildWindowWillProcessEventNotification = @"SSYDocChildWindowWillProcessEventNotification" ;
 NSString* const SSYDocChildWindowKeyEvent = @"SSYDocChildWindowKeyEvent" ;
 
 @implementation MyWindow
 
 - (void)sendEvent:(NSEvent *)event {
     NSDictionary* userInfo = [NSDictionary dictionaryWithObject:event
                                                          forKey:SSYDocChildWindowKeyEvent] ;
     [[NSNotificationCenter defaultCenter] postNotificationName:SSYDocChildWindowWillProcessEventNotification
													     object:self
     userInfo:userInfo] ;
     [super sendEvent:event] ;
 }
 
 @end
 
 Then register to hit this notification handler:
 
 - (void)didReceiveEvent:(NSNotification*)note {
     NSEventType eventType = [(NSEvent*)[[note userInfo] objectForKey:SSYDocChildWindowKeyEvent] type] ;
	 if (
		 (eventType == NSLeftMouseDown)
		 ||
		 (eventType == NSRightMouseDown)
		 ||
		 (eventType == NSOtherMouseDown)
		 ||
		 (eventType == NSKeyDown)
		 ) {
         [SSYHintArrow remove] ;
     }
 }
*/
+ (void)remove ;

@end

